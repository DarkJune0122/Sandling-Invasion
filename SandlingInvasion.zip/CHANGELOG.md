# Known issues:
- Item can drop down into a water - we need to search for a free tile.
- Item dropping might not be supported in multiplayer context.
- Item exploit that allows you to get higher odds on getting the next sandling.
- Compass might not appear after clearing out the room of enemies (actively under fixing)

# v0.1.3:
- Update the odds of item appearing: you now have much larger chance to find an extra compas, but chances go down the more of them you have on you. (pending)

### Misc:
- Updated mod deployment tools.
- Standartization of mod deployment tools is pending though.

# v0.1.2:
- Bonjo renewed dog item sprite.
- Sandling item - compas, can now spawn natually (10% after clearing out the room - Issac style appearance)

### Fixes:
- Fixed wrong sprite order on the left-side Sandling sprites.

# v0.1.0 - v0.1.1
- First release! **HYPERS**!
- Added Sandling - he replaces a regular dog as of right now.