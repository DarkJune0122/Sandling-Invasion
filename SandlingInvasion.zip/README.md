# Sandlings invade!
This is a community mod, specially made for Konoobi, VTuber!
- Twitch: https://www.twitch.tv/konoobi
- Twitter (X): https://x.com/konoobi_

We sincerely hope that you will enjoy playing with this mod!
<sup><sub><i>
And that she will be too busy to invade "No kobi" channel again.
</sub></sup></i>

# Contributors:
- Banjo ([@BanjoStream - X](https://x.com/BanjoStream))
- DarkJune ([@DarkJune0122 - X](https://x.com/DarkJune0122))

# Content:
- Sandling as **trustworthy** companion!
- *That's it! XD*

We hope you enjoy!

## How to install manually:
You need to place the mod in a folder where BepInEx plugins are.

We recommend using [R2ModMan launcher](https://thunderstore.io/c/enter-the-gungeon/p/ebkr/r2modman/) or launching mods.
Here is how to install everything:
1. First of all - install required dependencies from thunderstore, shown on a website you are currently on. (make sure to download the right versions!)
2. Download mod using "Manual Download" button.
3. Go to "C:\Users\\<User\>\AppData\Roaming\r2modmanPlus-local\ETG\profiles\\<Profile from R2ModMan\>\BepInEx\plugins"
4. Create new folder for a mod here (for example: "plugins\Sandling Invasion" folder)
5. Extract all the files in newly created folder.
6. **Important**! Move "sprites" folder from "...\\<ModName\>\plugins\\\*" in "...\\<ModName\>\\\*" (up, in a folder hierarchy), to overwrite dogo sprites. 

Now, if dependencies are installed - all done!
You can launch the game via launcher.

If you will have any issues - you can cantact our programmer directly via Discord:
User handle is 'DarkJune#0122' or 'darkjune'.