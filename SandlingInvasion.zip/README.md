# Sandlings invade!
This is a community mod, specially made for Konoobi, VTuber!
- Twitch: https://www.twitch.tv/konoobi
- Twitter (X): https://x.com/konoobi_

We sincerely hope that you will enjoy playing with this mod!
<sup><sub><i>
And that she will be too busy to invade "No kobi" channel again.
</sub></sup></i>

## Content:
- Sandling as **trustworthy** companion!
- *That's it! XD*

We hope you enjoy!

## Contributors:
- Banjo ([@BanjoStream - Twitter](https://x.com/BanjoStream))
- DarkJune (Discord: darkjune)
