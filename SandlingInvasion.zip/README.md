# MANUAL INSTALL ONLY!
Thunderstore messes-up internal structure of the mod!
Please, install mode manually T^T
You can download dependencies via launcher though.

## How to install:
You need to place the mod in a folder where BepInEx plugins are.

We recommend using [R2ModMan launcher](https://thunderstore.io/c/enter-the-gungeon/p/ebkr/r2modman/) or launching mods.
Here is how to install everything:
1. First of all - install all dependencies shown on this website (required versions are in dependency name at the end: 0.1.3 and so on)
2. Download mod using "Manual Download" button.
3. Go to "C:\Users\<User>\AppData\Roaming\r2modmanPlus-local\ETG\profiles\Default\BepInEx\plugins"
4. Create new folder for a mod here (for example: "plugins\Sandling Invasion" folder)
5. Extract all the files in newly created folder.
If dependencies are installed - all done!
You can launch the game via launcher.

If you will have any issues - you can cantact our programmer directly via Discord:
User handle is 'DarkJune#0122' or 'darkjune'.

*DarkJune: I'm really sorry to you, Bonjo and Konoobi for inconvenience -  working on resolving this \*^\* right now!*

# Sandlings invade!
This is a community mod, specially made for Konoobi, VTuber!
- Twitch: https://www.twitch.tv/konoobi
- Twitter (X): https://x.com/konoobi_

We sincerely hope that you will enjoy playing with this mod!
<sup><sub><i>
And that she will be too busy to invade "No kobi" channel again.
</sub></sup></i>

## Content:
- Sandling as **trustworthy** companion!
- *That's it! XD*

We hope you enjoy!

## Contributors:
- Banjo ([@BanjoStream - Twitter](https://x.com/BanjoStream))
- DarkJune (Discord: darkjune)
